import java.util.Scanner;
/**
 * The Machine program simulates a vending machine containing various items at different prices.
 * The program utilizes user interaction to simulate a real transaction, and keeps track of the 
 * user's balance, and displays items in the vending machine that are available to the user
 * based on their balance.
 * 
 * @author Kathleen Eife
 * @version 1.0
 * @since 2021-01-05
 **/
public class Machine {
	
	public static String[][] choices = {{"Chips", "Cookies", "Almonds", "Chocolate Cake"},{"Granola", "Brownie", "Fruit Snacks", "Dark Chocolate"},{"Peanut Butter Crackers", "Pretzels", "Trail Mix", "Candy"}};
	public static double[][] prices = {{3.25, 4.50, 4.00, 4.25}, {2.50, 2.25, 1.50, 3.50}, {2.50, 3.25, 3.00, 2.25}};
	public static int numRows = 3;
	public static int numCols = 4;
	
	/**
	 * Finds the number of options in the vending machine available to the user
	 * based on the prices of each item in the vending machine and the user's balance
	 * 
	 * @param deposit: balance in vending machine from which a number of options will be attained
	 * @return number of options available for the given balance
	 **/
	public static int getAmtOptions(double deposit) {
		int amt = 0;
		if(deposit < 1.5) 
			return 0;
		else if(deposit >= 4.5)
			return 12;
		else {
			for(int i = 0; i < numRows; i++) {
				for(int j= 0; j < numCols; j++) {
					if(deposit >= prices[i][j]) {
						amt++;
					}
				}
			}
		}
		return amt;
	}
	
	/**
	 * Finds the row and column of each available item affordable for the user based on the amount
	 * of options they have according to the items' prices and the user's balance
	 * 
	 * @param deposit: balance in vending machine
	 * @param amtOptions: the amount of items available for purchase based on the user's balance and items' prices
	 * @return an integer array with the first row containing the row coordinates of the available options,
	 * the second row containing the column coordinates of the available options, and every column representing
	 * another item afforded by the user
	 **/
	public static int[][] choose(double deposit, int amtOptions) {
		int options[][];
		options = new int[2][amtOptions];
		int indC = 0;
		if(amtOptions == 0) 
			return null;
		for(int i = 0; i < numRows; i++) {
			for(int j = 0; j < numCols; j++) {
				if(prices[i][j] <= deposit) {
					options[0][indC] = i;
					options[1][indC] = j;
					indC++;
				}
			}
		}
		return options;
	}
	/**
	 * Finds the price of the user's choice (if present in the choices array) using both the choices and prices arrays 
	 * 
	 * @param choice: Based on user input, will either hold the name of an item in the vending machine or an arbitrary String
	 * @return price for the user's vending machine item, or -1 for an incorrect input
	 **/
	public static double getPrice(String choice) {
		for(int i = 0; i < numRows; i++) {
			for(int j = 0; j < numCols; j++) {
				if(choice.equalsIgnoreCase(choices[i][j])) {
					return(prices[i][j]);
				}
			}
		}
		return -1;
	}
	
	public static void main(String[] args) {
		Scanner kbr = new Scanner(System.in);
		System.out.print("Deposit some money into the vending machine to make a purchase: $");
		double deposit = kbr.nextDouble();
		double price = 1;
		String item;
		boolean b = true;
		while(b) {
			if(deposit <= 0) {
				while(deposit <= 0) {
					System.out.print("Deposit an amount greater than 0 into the vending machine to make a purchase: $");
					deposit = kbr.nextDouble();
				}
			}
			else if(deposit < 1.5) {
				System.out.print("You do not have sufficient funds to make a purchase. Enter YES to make another deposit or NO to quit: ");
				String con = kbr.next();
				if(con.equalsIgnoreCase("NO")) {
					System.out.println("Your refunded amount is: $" + deposit);
					b = false;
					return;
				}
				while(deposit < 1.5) {
					System.out.print("Deposit more money into the vending machine to make a purchase: $");
					deposit += kbr.nextDouble();
				}
				System.out.println("Your balance is now: $" + deposit);
			}
			System.out.print("Based on your deposit, select one of the following items: ");
			int amtOptions = getAmtOptions(deposit);
			int options[][] = choose(deposit, amtOptions);
			for(int j = 0; j < amtOptions-1; j++) {
				System.out.print(choices[options[0][j]][options[1][j]] + ", ");
			}
			System.out.println(choices[options[0][amtOptions-1]][options[1][amtOptions-1]]);
			
			System.out.print("After reviewing your choices, what would you like to purchase? ");
			item = kbr.nextLine();
			item = kbr.nextLine();
			price = getPrice(item);
			
			if(price < 1.5) {
				while(price < 1.5){
					
					System.out.print("Please choose a valid item or enter QUIT to exit: ");
					item = kbr.nextLine();
					
					if(item.equalsIgnoreCase("QUIT")) {
						System.out.println("Your refunded amount is: $" + deposit);
						return;
					}
					else {
						price = getPrice(item);
					}
				}
				deposit -= price;
				System.out.println("After purchasing " + item + " you have a remaining balance of $" + deposit);
			}
			else {
				deposit -= price;
				System.out.println("After purchasing " + item + " you have a remaining balance of $" + deposit);
				System.out.print("To purchase another item enter YES or enter NO to quit: ");
				String proceed = kbr.nextLine();
				if(proceed.equalsIgnoreCase("NO")) {
					System.out.println("Your refunded amount is: $" + deposit);
					b = false;
				}
			}
			if(b) {
				System.out.print("Make another deposit or enter 0 to make a purchase with remaining balance of $" + deposit + ": $");
				deposit += kbr.nextDouble();
				System.out.println("Your balance is now: $" + deposit);
				if(deposit == 0) {
					System.out.print("Would you like to quit? Enter YES or NO: ");
					String quit = kbr.nextLine();
					if(quit.equalsIgnoreCase("yes"))
						b = false;
				}
			}	
		}
		kbr.close();
	}	
}
